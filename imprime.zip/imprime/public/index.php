<?php 

require '../app/init.php';
$app = new App();

 ?>