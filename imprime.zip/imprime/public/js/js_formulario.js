var nr_paginas;
var formato;
var tinta;
var cara;
var precio_Total;
const precio_N=0.02;
const precio_C=0.07;
const precio_Spiral=0.8;
const precio_Libro=1.5;



/* metodo que me devuele el boton seleccionado*/
function getRadioButtonSelectedValue(ctrl){
    for(i=0;i<ctrl.length;i++){
        if(ctrl[i].checked) return ctrl[i].value;
    }
}
/* metodo que valida los campos del formulario */
	function validacion(){
		/* recojo valor del numero de paginas */
			nr_paginas=document.getElementById("paginas").value;
			if(paginas==""){
			    nr_paginas=0;
			}
		/* recojo valor del formato */
      formato=getRadioButtonSelectedValue(document.getElementsByName('formato'));
        /* recojo valor del select tinta */
			idtinta=document.getElementById("tinta");
			tinta=idtinta.options[idtinta.selectedIndex].value;
		/* recojo el valor de caras */
    cara=getRadioButtonSelectedValue(document.getElementsByName('caras'));

    /* recogo el valor del tipo de encuadrenacion */
    idtipo=document.getElementById("tipoEnc");
	tipo=idtipo.options[idtipo.selectedIndex].value;
    	
    calcularPresupuesto(nr_paginas,formato,tinta,cara);
}

function calcularPresupuesto(nr_paginas,formato,tinta,cara){
	/* costeTotal=nr_paginas*coste_formato*precio_tinta+tipo_encuadrenacion; */
	var car='';
	switch(cara) {
		case('1'):
		car='A una cara';
		break;
		case('2'):
		car='A doble cara';
		break;
	}

	var coste=0;
	switch(formato) {
		case('A4'):
		coste=1;
		break;
		case('A3'):
		coste=2;
		break;
	}

	var precio=0.0;
	switch(tinta){
		case('N'):
		tinta='Negro';
		precio=precio_N;
		break;
		case('C'):
		tinta='Color';
		precio=precio_C;
		break;
	}
	var precioTipo=0.0;
	switch(tipo){
		case('ninguna'):
		precioTipo=0.0;
		break;
		case('libro'):
		precioTipo=precio_Libro;
		break;
		case('espiral'):
		precioTipo=precio_Spiral;
		break;
	}

	nr_paginas=parseInt(nr_paginas);
	coste=parseInt(coste);
	var c=nr_paginas*coste*precio+precioTipo;
	costeTotal=c.toFixed(2);

	var t1=document.createTextNode('Numero de paginas:'+nr_paginas);
	var t2=document.createTextNode('Formato de hoja: '+formato);
	var t3=document.createTextNode('Tipo de tinta: '+tinta);
	var t4=document.createTextNode('Impressió: '+car);
	var t5=document.createTextNode('Tipo de encuadrenacion: '+ tipo);
	var t6=document.createTextNode('Coste Total = '+costeTotal+'€');

	x=document.getElementById('contenido');
	while(x.hasChildNodes()){
	x.removeChild(x.firstChild);
	}
	b=document.createElement('br');
	x.appendChild(b);
	h3=document.createElement('h3');
	th3=document.createTextNode('Tu presupuesto es:');
	h3.appendChild(th3);
	h3.setAttribute("class", "ht");
	x.appendChild(h3);

	p=document.createElement('p');
	p.appendChild(t1);
	x.appendChild(p);
	
	p1=document.createElement('p');
	p1.appendChild(t2);
	x.appendChild(p1);

	p2=document.createElement('p');
	p2.appendChild(t2);
	x.appendChild(p2);

	p3=document.createElement('p');
	p3.appendChild(t3);
	x.appendChild(p3);

	p4=document.createElement('p');
	p4.appendChild(t4);
	x.appendChild(p4);

	p5=document.createElement('p');
	p5.appendChild(t5);
	x.appendChild(p5);

	h=document.createElement('h3');
	h.appendChild(t6);
	x.appendChild(h);
}