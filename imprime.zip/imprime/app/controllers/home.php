<?php 

require_once('../app/models/AccionesBD.php');

 class home extends Controller{

	public function index(){
		$this->view('home/index');
	}

	public function formularioImprimir(){
		$this->view('./home/formularioImprimir');
	}
}

 ?>