<?php 

public class Pedido(){

	/* propriedades */
	private $fechaPedido;
	private $nr_copias;
	private $formato;
	private $caras;
	private $tinta;
	private $tipo_encuadernacion;
	private $costeTotal;
	const COSTE_NEGRO = 0,02;
	const COSTE_COLOR = 0,07;


	/**
	 * Class Constructor
	 * @param    $fechaPedido   
	 * @param    $nr_copias   
	 * @param    $formato   
	 * @param    $caras   
	 * @param    $tinta   
	 * @param    $tipo_encuadernacion    
	 */
	public function __construct($fechaPedido, $nr_copias, $formato, $caras, $tinta, $tipo_encuadernacion){
		$this->setFechaPedido($fechaPedido);
		$this->setNrCopias($nr_copias);
		$this->setFormato($formato);
		$this->setCaras($caras);
		$this->setTinta($tinta);
		$this->setTipoEncuadernacion($tipo_encuadernacion);
	}
    /**
     * @param mixed $fechaPedido
     *
     * @return self
     */
    public function setFechaPedido($fechaPedido){
        $this->fechaPedido = $fechaPedido;
    }

    /**
     * @return mixed
     */
    public function getFechaPedido(){
        return $this->fechaPedido;
    }


    /**
     * @return mixed
     */
    public function getNrCopias(){
        return $this->nr_copias;
    }

    /**
     * @param mixed $nr_copias
     */
    public function setNrCopias($nr_copias){
        $this->nr_copias = $nr_copias;
    }

    /**
     * @return mixed
     */
    public function getFormato(){
        return $this->formato;
    }

    /**
     * @param mixed $formato
     *
     * @return self
     */
    public function setFormato($formato){
        $this->formato = $formato;
    }

    /**
     * @return mixed
     */
    public function getCaras(){
        return $this->caras;
    }

    /**
     * @param mixed $caras
     */
    public function setCaras($caras){
        $this->caras = $caras;
    }

    /**
     * @return mixed
     */
    public function getTinta(){
        return $this->tinta;
    }

    /**
     * @param mixed $tinta
     */
    public function setTinta($tinta){
        $this->tinta = $tinta;
    }

    /**
     * @return mixed
     */
    public function getTipoEncuadernacion(){
        return $this->tipo_encuadernacion;
    }

    /**
     * @param mixed $tipo_encuadernacion
     */
    public function setTipoEncuadernacion($tipo_encuadernacion){
        $this->tipo_encuadernacion = $tipo_encuadernacion;
    }

    /**
     * @return mixed
     */
    public function getCosteTotal(){
    	if($this->getTinta()=='N'){
    		$this->costeTotal=$this->getNrCopias()*COSTE_NEGRO;
    	}else if($this->getTinta()=='C'){
    		$this->costeTotal=$this->getNrCopias()*COSTE_COLOR;
    	}
        return $this->costeTotal;
    }

/* metodo que nos da toda la información de la clase de forma organizada con formatos establcidos */
    public function __toString(){
        return $this->getFechaPedido().','.$this->getNrCopias().','.$this->getFormato().','.$this->getCaras().','.$this->getTinta().','.$this->getTipoEncuadernacion().','.$this->getCosteTotal();
    }



}





 ?>