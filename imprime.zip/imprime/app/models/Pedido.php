<?php 

class Pedido{

	/* propriedades */
	private $fechaPedido;
	private $nr_copias;
	private $formato;
	private $caras;
	private $tinta;
	private $tipo_encuadernacion;
    private $metodo_envio;
	private $costeTotal;
    private $fichero;
	const COSTE_NEGRO = 0.02;
	const COSTE_COLOR = 0.07;
    const PRECIO_LIBRO=1.5;
    const PRECIO_ESPIRAL=0.8;


	/**
	 * Class Constructor
	 * @param    $fechaPedido   
	 * @param    $nr_copias   
	 * @param    $formato   
	 * @param    $caras   
	 * @param    $tinta   
	 * @param    $tipo_encuadernacion  
     * @param    $metodo_envio  
	 */
	public function __construct($nr_copias ='', $formato='', $caras='', $tinta='', $tipo_encuadernacion='',$metodo_envio=''){
		$this->setNrCopias($nr_copias);
		$this->setFormato($formato);
		$this->setCaras($caras);
		$this->setTinta($tinta);
		$this->setTipoEncuadernacion($tipo_encuadernacion);
	    $this->setMetodoEnvio($metodo_envio);
    }

     /**
     *  Metodo que me fija los datos que me pasan es como segundo constructor 
     */
    public function fijarDatos($datos){
       $this->setNrCopias($datos['paginas']);
        $this->setFormato($datos['formato']);
        $this->setTinta($datos['tinta']);
        $this->setCaras($datos['caras']);
        $this->setTipoEncuadernacion($datos['tipoEnc']);
        $this->setMetodoEnvio($datos['metodoEnvio']);
    }



    /**
     * @param mixed $fechaPedido
     *
     * @return self
     */
    public function setFechaPedido($fechaPedido){
        $this->fechaPedido = $fechaPedido;
    }

    /**
     * @return mixed
     */
    public function getFechaPedido(){
        return $this->fechaPedido;
    }


    /**
     * @return mixed
     */
    public function getNrCopias(){
        return $this->nr_copias;
    }

    /**
     * @param mixed $nr_copias
     */
    public function setNrCopias($nr_copias){
        $this->nr_copias = $nr_copias;
    }

    /**
     * @return mixed
     */
    public function getFormato(){
        return $this->formato;
    }

    /**
     * @param mixed $formato
     *
     * @return self
     */
    public function setFormato($formato){
        $this->formato = $formato;
    }

    /**
     * @return mixed
     */
    public function getCaras(){
        return $this->caras;
    }

    /**
     * @param mixed $caras
     */
    public function setCaras($caras){
         $car='';
        switch($caras) {
        case('1'):
            $car='A una cara';
        break;
        case('2'):
            $car='A doble cara';
        break;
        }
        $this->caras = $car;
    }

    /**
     * @return mixed
     */
    public function getTinta(){
        return $this->tinta;
    }

    /**
     * @param mixed $tinta
     */
    public function setTinta($tinta){
        $this->tinta = $tinta;
    }

    /**
     * @return mixed
     */
    public function getTipoEncuadernacion(){
        return $this->tipo_encuadernacion;
    }

    /**
     * @param mixed $tipo_encuadernacion
     */
    public function setTipoEncuadernacion($tipo_encuadernacion){
        $this->tipo_encuadernacion = $tipo_encuadernacion;
    }

    /**
     * @return mixed
     */
    public function getMetodoEnvio(){
        return $this->metodo_envio;
    }

    /**
     * @param mixed $metodo_envio
     */
    public function setMetodoEnvio($metodo_envio){
        $this->metodo_envio = $metodo_envio;
    }

    /**
     * @return mixed
     */
    public function getFichero(){
        return $this->fichero;
    }

    /**
     * @param mixed $fichero
     */
    public function setFichero($fichero){
        $this->fichero = $fichero;
    }

    /**
     * costeTotal=nr_paginas*coste_formato*precio_tinta+tipo_encuadrenacion;
     * @return CosteTotal
     */
    public function getCosteTotal(){

        $coste=0;
    switch($this->getformato()) {
        case('A4'):
            $coste=1;
        break;
        case('A3'):
            $coste=2;
        break;
    }
        $precio=0.0;
    switch($this->getTinta()){
        case('N'):
        $this->setTinta('Negro');
            $precio=self::COSTE_NEGRO;
        break;
        case('C'):
            $this->setTinta('Color');
            $precio=self::COSTE_COLOR;
        break;
    }

        $precioTipo=0.0;
    switch($this->getTipoEncuadernacion()){
        case('ninguna'):
            $precioTipo=0.0;
        break;
        case('libro'):
            $precioTipo=self::PRECIO_LIBRO;
        break;
        case('espiral'):
            $precioTipo=self::PRECIO_ESPIRAL;
        break;
    }
        $c=$this->getNrCopias()*$coste*$precio+$precioTipo;
        $costeTotal=round($c,2);
    return $costeTotal;
}

/* metodo que nos da toda la información de la clase de forma organizada con formatos establcidos */
    public function __toString(){
        return 'nr_copias'.$this->getNrCopias().',formato'.$this->getFormato().',caras'.$this->getCaras().',tinta'.$this->getTinta().',tipoEnc'.$this->getTipoEncuadernacion().',metodo_envio'.$this->getMetodoEnvio().',fichero'.$this->getFichero();
    }



}




 ?>