<?php include_once('conf.php'); ?>
<body>
<main>
	<section>
		<h3>Rellene formulario para imprimir</h3>
			<form enctype="multipart/form-data" action="contenido.php" method="post">
				<label><?=LBL_DOCUMENTO ?></label>
				<input type="file" name="foto" id="foto" required="required" />
				<br />
				<label><?=LBL_FORMATO ?></label>
				<input type="radio" name="formato" value="A4" required="required" /><label><?=LBL_A4?></label>
				<input type="radio" name="formato" value="A3" required="required" /><label><?=LBL_A3?></label>
				<br />
				<label><?=LBL_CARAS ?></label>
				<br />
				<input type="radio" name="caras" value="1" required="required" /><label><?=LBL_CARA_UNICA ?></label>
				<br>
				<input type="radio" name="caras" value="2" required="required" /><label><?=LBL_DOBLE_CARA ?></label>
				<br />
				<label><?=LBL_TIPO_COLOR ?></label>
				<select name="tinta">
					<option value="N" required="required" ><?=LBL_COLOR_NEGRO ?></option>
					<option value="C" required="required" ><?=LBL_COLOR_COLOR ?></option>
				</select>
				<br />
				<label><?=LBL_NR_COPIAS ?></label>
				<input type="text" name="copias" required="required" />
				<br />
				<input type="submit" value="Enviar Datos" class="butonrojo" />
			</form>
	</section>
</main>
<?php include_once('pie.php'); ?>