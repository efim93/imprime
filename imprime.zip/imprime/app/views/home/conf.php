<?php 
	include_once('cabecera.php');
 	define('LBL_FORMATO' , 'Formato de hoja: ');
 	define('LBL_A4', 'A4');
 	define('LBL_A3','A3');
 	define('LBL_CARAS', 'Impressió: ');
 	define('LBL_SEXO','Sexo: ');
 	define('LBL_CARA_UNICA','A una cara (Cara externa)');
 	define('LBL_DOBLE_CARA','A doble caras (Cara externa + Cara interna)');
 	define('LBL_TIPO_COLOR','Tipo de tinta: ');
 	define('LBL_COLOR_NEGRO','Negro');
 	define('LBL_COLOR_COLOR','Color');
 	define('LBL_NR_COPIAS','Numero de Copias: ');
 	define('LBL_DOCUMENTO','Documento: ');

 ?>