<?php		
		
class enviaMail
{				
		
	public function sendMailCliente($mDestinatario, $contenidoMensaje, $titulo, $idCliente)
	{		
		
		$contenidoMensaje.=contacta();
		
		$mensaje = file_get_contents("../plantillaMailCliente.html");
		$mensaje = str_replace("++MODIFICABLE++", $contenidoMensaje, $mensaje);		
						
		// Versión para ver en web            
	
		$file_name = $idCliente.".html";
		$mensaje = str_replace("++aqui++", $file_name, $mensaje);		
		file_put_contents(pathMail.$file_name, $mensaje);
			
		// Para enviar un correo HTML, debe establecerse la cabecera Content-type	
		$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
		$cabeceras .= 'Content-type:text/html;charset=UTF-8' . "\r\n";
		$cabeceras .= 'From: '.correoProduccion.  "\r\n";	
			
		return mail($mDestinatario, '=?utf-8?B?'.base64_encode($titulo).'?=', $mensaje, $cabeceras);		
																							
	}
	
	public function sendMailProductor($mRemitente, $contenidoMensaje, $titulo, $idCliente, $adjuntos){	//El remitente es el cliente							
		
		$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
		$cabeceras .= 'Content-type:text/html;charset=UTF-8' . "\r\n";
		$cabeceras .= 'From: '.$mRemitente. "\r\n";
		$cabeceras .= 'X-Confirm-Reading-To: '.$mRemitente. "\r\n";

		$constante = "const archivos = array(";
		
		foreach ($adjuntos as $archivo)
			{															
				$contenidoMensaje .= '<br><a href="http://imprimirbarato.es/serverService.php?orden=2&file='.$archivo->getRutaArchivo().'&name='.$archivo->getDocument()['name'].'" title="Descargar" target="_top">'.$archivo->getDocument()['name'].'</a>';
							
				$constante .= "'".$archivo->getRutaArchivo()."', ";
				
				if ($archivo->getRutaPortada()!=null)
				{																		
					$contenidoMensaje .= '<br><a href="http://imprimirbarato.es/serverService.php?orden=2&file='.$archivo->getRutaPortada().'&name='.$archivo->getPortada()['name'].'" title="Descargar" target="_top">'.$archivo->getPortada()['name'].'</a>';								
				
					$constante .= "'".$archivo->getRutaPortada()."', ";
				}		
																				
			}
		
		$constante = substr($constante, 0, strlen($constante)-2).");";

		$contenidoMensaje .= '<br><br><a href="http://imprimirbarato.es/serverService.php?orden=1&idPedido='.$idCliente.'.php" title="Borrar archivos del servidor y ordenar reparto" target="_top">Borrar archivos del servidor y ordenar el reparto</a>';								
		
		//Crea orden de reparto						
		$borrado = 'foreach(self::archivos as $ruta)
		{
			if (file_exists($ruta))
			{
				unlink($ruta);
				echo " borrado: ".basename($ruta).";"."\n";
			}
		}';
			
		$metas;
				  		
		foreach ($_SESSION["envio"] as $clave => $valor)
		{
			$metas .= '<meta name="'.$clave.'" content="'.$valor.'">'."\n";
		}
		
		$metas .= '<meta name="valor" content="'.number_format($_SESSION['precio'], 2).'€">'."\n";
		
		$reparto = file_get_contents("../plantillaReparto.php");
		$reparto = str_replace("//--->const archivos array", $constante, $reparto);	
		$reparto = str_replace("//--->borrado de archivos", $borrado, $reparto);
		$reparto = str_replace("<!--inserción de metas-->", $metas, $reparto);
		file_put_contents("../ordenes/".$idCliente.".php", $reparto);
		
		
		return mail(correoProduccion, '=?utf-8?B?'.base64_encode($titulo).'?=', $contenidoMensaje, $cabeceras);	//correoProduccion
	}
			
}

?>
