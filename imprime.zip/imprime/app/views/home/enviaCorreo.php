<?php		
include_once('cabecera_dentro.php');
include_once('conf.php');


$d=explode('|', $_POST['datos']);

$campos=array();
foreach($d as $key => $value) {
	$registro=$value;
	$f=explode(':',$registro);
	array_push($campos, $f);
}

$cosas='';
foreach ($campos as $key) {
			foreach ($key as $key2=>$value) {
				$cosas.=$value."\n";
			}	
	$cosas.="<br>";
}

$mm="
<ul class='vmenu izquierda'><li><a class='logo'>ImprimirBARATO</a></li></ul>
	<p>¡Gracias por confiar en nosotros!</p>
	+++MODIFICABLE+++
<p>¡LLámanos para cualquier cosa al 917 712 218 de L-V de 9.30 a 19:00 y te atenderemos encatados!</p>
<a class='pad-d' href='http://imprimirbarato.es'>ir a imprimirbarato.es</a>
<p class='titlos'>Confidencialidad</p>
<p>La información que pueda contener este mensaje, así como su(s) archivo(s) adjunto(s), es totalmente confidencial y va dirigida única y exclusivamente a su destinatario. Si usted lee este mensaje y no es el destinatario señalado, o la persona responsable de entregar el mensaje al destinatario, o ha recibido esta comunicación por error, le recordamos que está prohibida, y puede ser ilegal, cualquier divulgación, distribución o reproducción de esta comunicación, y le rogamos que nos lo notifique inmediatamente y nos devuelva el mensaje original a la dirección <a href='mailto:produccion@imprimirbarato.es' accesskey='5'> produccion@imprimirbarato.es</a>. Gracias.</p>
<p class='titlos'>Virus</p>
<p>Se han tomado las medidas pertinentes para asegurar que este mensaje y sus ficheros adjuntos estén libres de virus. No obstante, recomendamos encarecidamente que el receptor del mismo proceda igualmente a utilizar los medios necesarios para asegurarse de la inexistencia de virus y/o código malicioso alguno.</p>
	<p class='titlos'>Protección de datos</p>
<p>De conformidad con lo establecido en el Art. 5 de la Ley Orgánica 15/1999 de diciembre de Protección de Datos de Carácter Personal, por el que se regula el derecho de información en la recogida de datos le informamos de los siguientes extremos:
<ul>
<li>Los datos de carácter personal que nos ha suministrado en esta y otras comunicaciones mantenidas con usted no serán objeto de tratamiento en ningún fichero y serán eliminados una vez finalice el servicio y pasados treinta días.</li>
<li>Estos datos no serán cedidos a terceros, salvo las cesiones legalmente imperativas y las necesarias para llevar a cabo el servicio; como lo es con la empresa de transportes.</li>
<li>Los datos solicitados a través de esta y otras comunicaciones son de suministro obligatorio para la prestación del servicio. Estos son adecuados, pertinentes y no excesivos.</li>
<li>Su negativa a suministrar los datos solicitados implica la imposibilidad de prestarle el servicio.</li>
<li>Asimismo, le informamos de la posibilidad de ejercitar los correspondiente derechos de acceso, rectificación, cancelación y oposición de conformidad con lo establecido en la Ley 15/1999 ante Envialia como responsables del fichero que ellos puedan generar con motivo del transporte. Los derechos mencionados los puede ejercitar a través de los medios indicados en: <a href='http://www.envialia.com/politica-de-privacidad.html' accesskey='6'>www.envialia.com/politica-de-privacidad.html</a>.</li></ul></p>
<p class='titlos'>Servicio de comunicaciones por correo electrónico</p>
<p>Usted ha recibido este correo electrónico por haber dado su consentimiento previo a imprimirbarato.es, a través del procedimiento de solicitud de servicio, mediante la web imprimirbarato.es. Prestarle los servicios requiere que nos comuniquemos con usted y dichas comunicaciones cesarán una vez termine el mismo.</p>
<p>© imrpimirbarato.es 2019. Todos los derechos reservados.</p>";
$o="<h3 class='izq pad-d'>Datos de envio:</h3>";
$contenido=$o."<p class='titlos pad-d'>".$cosas."</p>";
$mm = str_replace("+++MODIFICABLE+++", $contenido, $mm);
?>
<body class="pa">
	<main>
		<section>
		<div class="flotar">
			<div class="pad-d amarillo caja">
			<h4 class="izq pad-d">Contenido del Pedido:</h4>
				<?=$cosas?>
			</div>
		</div>
			<div class="flIzq" >
				<h3>Elige una forma de pago:</h3>
				<form action="" method="" class="pad-all">
					<input type="radio" name="pago" value="visa" />
					<img src="../../public/img/visa-mastercard.png" class="peq" alt="visa-mastercard" title="visa-mastercard" requiere="requiere" />
					<input type="radio" name="pago" value="paypal" />
					<img src="../../public/img/paypal.jpeg" class="peq" alt="paypal" title="paypal" />
					<input type="radio" name="pago" value="transferencia" />
					<img src="../../public/img/transferencia.jpeg" class="peq" alt="transferencia" title="transferencia" /><br />
			<!--		<label class="pad-d"><?=LBL_DEJA_CORREO?></label>
					<input type="text" name="correo" id="correo" placeholder="ejemplo@mail.com">
					<br />
			-->
					<input type="submit" name="enviar" value="Enviar Opcion" class="butonrojo">
				</form>
			</div>
			<div><h3 class="ht">Recibiras un correo de confirmación</h3></div>
		</div>
		<div>
			
		</div>
		</section>
	</main>
<?php include_once('pie_dentro.php'); ?>
