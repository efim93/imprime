<?php
include_once 'cabecera.php'; ?>
	<body class="pa">
		<h2 id="servicios">Nuestros servicios</h2><hr>
		<div class="centrado">
			<table class="texto">
				<thead>
					<tr>
						<th scope="col">Tipos de impresión</th>
						<th scope="col">Forma de impresión</th>
						<th scope="col">Acabado</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>- Blanco y Negro</td>
						<td>- Una cara</td>
						<td>- Espiral</td>
						
					</tr>
					<tr>
						<td>- Color</td>
						<td>- Doble cara</td>
						<td>- Sin encuadernar</td>
					</tr>
					<tr>
						<td><img src="img/cartucho.png" class="imagines" /></td>
						<td><img src="img/paper.png" class="imagines" /></td>
						<td><img src="img/encuadernar.png" class="imagines" /></td>
					</tr>
				</tbody>
			</table>
		</div>
			<p class="letra">¡ Rompemos el mercado de las fotocopias !</p>
			<p class="letra"><span class="colores">COLOR 0,07€</span> o <span class="negros">NEGRO 0,02€</span></p>
			<div class="centrado">
				<a href="home/formularioImprimir">
				<button class="butonazul">Calcula tu presupuesto ahora</button>
				</a>
			</div>
		<script src="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.js" data-cfasync="false"></script>
	</body>
</html>
<?php include 'pie.php'; ?>