<?php
include_once 'cabecera.php'; ?>
	<body class="pa" onload="inicializa();">
			<p class="letra">¡ Rompemos el mercado de las fotocopias !</p>
			<p class="letra"><span class="colores">COLOR 0,07€</span> Y BLANCO Y NEGRO <span class="negros">0,02€</span></p>
			<div class="centrado">
				<a href="formularioImprimir">
				<button class="butonazul">Crea tu pedido ahora sin registros</button>
				</a>
			</div>
		<h2 id="servicios">Nuestros servicios</h2><hr>
		<div class="centrado">
			<table class="texto">
				<thead>
					<tr>
						<th scope="col">Tipos de impresión</th>
						<th scope="col">Forma de impresión</th>
						<th scope="col">Acabado</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>- Blanco y Negro</td>
						<td>- Una cara</td>
						<td>- Espiral</td>
						
					</tr>
					<tr>
						<td>- Color</td>
						<td>- Doble cara</td>
						<td>- Sin encuadernar</td>
					</tr>
					<tr>
						<td><img src="img/cartucho.png" class="imagines" /></td>
						<td><img src="img/paper.png" class="imagines" /></td>
						<td><img src="img/encuadernar.png" class="imagines" /></td>
					</tr>
				</tbody>
			</table>
		</div>
			<p class="texto rodondeado">Imprimimos en hojas A4 de 80 gramos, ECO -EFC, ISO 9706-.</p>
		<script src="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.js" data-cfasync="false"></script>
	</body>
</html>
<?php include 'pie.php'; ?>