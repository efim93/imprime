<?php 

include_once('conf.php');
include_once('cabecera_dentro.php');
include_once('../app/models/Pedido.php');

$p=new Pedido();
$p->fijarDatos($_POST,$_FILES['fichero']['name']);

$costeTotal=$p->getCosteTotal();

$paginas=$p->getNrCopias();
$formato=$p->getFormato();
$color=$p->getTinta();
$caras=$p->getCaras();
$tipo=$p->getTipoEncuadernacion();
$metodo=$p->getMetodoEnvio();
$fichero=$p->getFichero();
$d=$p->__toString();
$e=explode(',',$d);
$datos='';
for($i=0;$i<count($e); $i++){ 
	$datos.=$e[$i].'-';
}

	/* guardo el fichero */
	$fichero_subido = 'ficheros/'. basename($fichero);

if (($_FILES["fichero"]["type"] == "application/pdf")&&($_FILES["fichero"]["size"] < 100000000)) {
		move_uploaded_file($_FILES["foto"]["tmp_name"], "ficheros/" . $fichero); 
	}

 ?>
 <body  class="pa">
		<h2>Revisa tus datos del Pedido</h2>
<main>
	<section>
	<div class="centrado amarillo">
		<h3>Tus Datos introducidos son:</h3>
		<br />
		<div class="pad-d pad-all">
		<label><?=LBL_NR_PAGINAS ?></label>
		<label><?=$paginas ?></label>
		<br />
		<label><?=LBL_FORMATO ?></label>
		<label><?=$formato ?></label>
		<br />
		<label><?=LBL_TIPO_COLOR ?></label>
		<label><?=$color ?></label>
		<br />
		<label><?=LBL_CARAS ?></label>
		<label><?=$caras ?></label>
		<br />
		<label><?=LBL_TIPO_ENC ?></label>
		<label><?=$tipo ?></label>
		<br />
		<label><?=LBL_METODO ?></label>
		<label><?=$metodo ?></label>
		<hr />
		<h3><?=LBL_PRECIOTOTAL.' '.$costeTotal .' €' ?></h3>
		<a href="crearPedido" class="butonazul">Volver atras</a>
		</div>
		<form action="enviarCorreo" method="POST">
			<input type="hidden" name="datos" value="<?=$datos ?>" />
		<input type="submit" name="enviarCorreo" class="butonrojo" value="Enviar Pedido">
		</form>
	</div>
	</section>
</main>
</body>
<?php 
include_once('pie.php');
 ?>